package sample4;

public class Tuesday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "ȭ���� �Դϴ�";
	}
}