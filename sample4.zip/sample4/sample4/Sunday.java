package sample4;

public class Sunday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "�Ͽ��� �Դϴ�";
	}
}