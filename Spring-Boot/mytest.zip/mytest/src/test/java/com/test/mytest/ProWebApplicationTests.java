package com.test.mytest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
