package com.myjpa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.myjpa.service.MyService;

@Controller
public class PageController {
	@Autowired
	private MyService service;
	
	// localhost:9898/pagelist
	@RequestMapping("/pagelist02")
	public String index(Model model) {
		model.addAttribute("books", service.findAll02());
		return "index";
	}
}
