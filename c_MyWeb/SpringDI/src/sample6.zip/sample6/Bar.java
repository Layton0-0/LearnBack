﻿package sample6;

public class Bar {
	
	public Bar() {
		System.out.println("Bar 객체생성");
	}
	public void pr(){
		System.out.println("Bar 클래스의 pr() 메서드...");
	}
}

