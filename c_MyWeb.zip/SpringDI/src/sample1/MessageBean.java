package sample1;

public interface MessageBean {
	void sayHello();     //public abstract void sayHello();
	
}