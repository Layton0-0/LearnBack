package calculator;

public class Calc {

	int sum;
	
	int CalcSum(int a, int b, int c, int d) {
		
		
		
		return a+b+c+d;
	}
}
