package yoon.yoonspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YoonSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(YoonSpringApplication.class, args);
	}

}
