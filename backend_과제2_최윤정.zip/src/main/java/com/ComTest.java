package com;

import com.vo.MemberVo;

public class ComTest {

	public static void main(String[] args) {
		MemberVo vo = new MemberVo();
		vo.setAddress("Seoul");
		vo.setAge(11);
		vo.setBirth("2020-11-11");

	}

}
