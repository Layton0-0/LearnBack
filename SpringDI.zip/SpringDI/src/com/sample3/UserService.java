package com.sample3;

public interface UserService {
	void addUser(UserVo vo);

}
