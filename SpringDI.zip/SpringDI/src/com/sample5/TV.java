package com.sample5;

public interface TV {
	
	public void powerOn();
	
	public void powerOff();
	
	public void volumnUp();
	
	public void volumnDown();
	

}
