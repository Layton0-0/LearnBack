package com.sample4;

public class Tuesday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "화요일 입니다.";
	}
}