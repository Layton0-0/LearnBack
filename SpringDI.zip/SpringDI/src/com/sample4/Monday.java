package com.sample4;


public class Monday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "월요일 입니다.";
	}
}
