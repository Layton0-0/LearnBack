package com.sample4;

public class Thursday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "목요일 입니다.";
	}
}