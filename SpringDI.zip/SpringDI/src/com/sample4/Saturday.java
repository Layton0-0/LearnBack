package com.sample4;

public class Saturday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "토요일 입니다.";
	}
}