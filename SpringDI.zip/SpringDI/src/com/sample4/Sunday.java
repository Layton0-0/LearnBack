package com.sample4;

public class Sunday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "일요일 입니다.";
	}
}