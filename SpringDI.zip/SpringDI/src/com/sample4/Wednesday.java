package com.sample4;

public class Wednesday extends AbstractTest{
	@Override
	public String dayInfo() {
		return "수요일 입니다.";
	}
}
